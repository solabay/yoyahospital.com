<footer id="footer">
	<!-- Start Footer Top -->
	<div class="footer-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-3">
					<div class="single-footer-widget">
						<div class="section-heading">
							<h2>About Us</h2>
							<div class="line"></div>
						</div>
						<p>A voluntary, acute-care, YOYA Hospital endeavors to provide excellent health
							care services in a compassionate and humane manner to the people who live and work in
							Adama and its surrounding areas.</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-3">
					<div class="single-footer-widget">
						<div class="section-heading">
							<h2>Our Service</h2>
							<div class="line"></div>
						</div>
						<ul class="footer-service">
							<li><a href="#"><span class="fa fa-check"></span>Pathology</a></li>
							<li><a href="#"><span class="fa fa-check"></span>ENT</a></li>
							<li><a href="#"><span class="fa fa-check"></span>Ophtalmology</a></li>
							<li><a href="#"><span class="fa fa-check"></span>Oncology </a></li>
							<li><a href="#"><span class="fa fa-check"></span>Rheumatology</a></li>
							<li><a href="#"><span class="fa fa-check"></span>Physiotherapy</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-3">
					<div class="single-footer-widget">
						<div class="section-heading">
							<h2>Tags</h2>
							<div class="line"></div>
						</div>
						<ul class="tag-nav">
							<li><a href="#">Internal Medicine</a></li>
							<li><a href="#">Surgery</a></li>
							<li><a href="#">Pediatric</a></li>
							<li><a href="#">Gynacology</a></li>
							<li><a href="#">Oncology</a></li>
							<li><a href="#">Ortho</a></li>
							<li><a href="#">Cardiology</a></li>
							<li><a href="#">Ophthalmology</a></li>
							<li><a href="#">Diabetes</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-3">
					<div class=" single-footer-widget ">
						<div class=" section-heading">
							<h2>Contact Info</h2>
							<div class="line"></div>
						</div>
						<p>Feel free to contact us any moment using any of the details provided below.</p>
						<address class="contact-info">
							<p><span class="fa fa-home"></span>Adama,Arround Panafrik 
							Next to Robi Hotel, <i>Adama,Ethiopia</i></p>
							<p><span class="fa fa-phone"></span>022 212 0599</p>
							<p><span class="fa fa-envelope"></span>yoyahospital@gmail.com</p>
						</address>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Start Footer Middle -->
	<div class="footer-middle">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="footer-copyright">
						<?= "<p>&copy; Copyright-" . date("Y") . " <a href=\"index.php\">Yoya Hospital</a></p>"; ?>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="footer-social">
						<a href="https://www.facebook.com/imidiotic12"><span class="fa fa-facebook"></span></a>
						<a href="https://twitter.com/piyushbhutoria9"><span class="fa fa-twitter"></span></a>
						<a href="https://www.linkedin.com/in/piyushh-bhutoria-for-you/"><span class="fa fa-linkedin"></span></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Start Footer Bottom -->
	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p>Design & Developed By <a rel="nofollow">Dawit Solomon(MD)</a></p>
				</div>
			</div>
		</div>
	</div>
</footer>
