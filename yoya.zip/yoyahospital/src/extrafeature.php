<section id="extraFeatures">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="departments-area">
					<div class="section-heading">
						<h2>Our Services</h2>
						<div class="line"></div>
					</div>
					<!-- Start Departments Accordion -->
					<div class="panel-group custom-panel" id="accordion">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
									Emergency Care <span class="fa fa-minus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseOne" class="panel-collapse collapse in">
								<div class="panel-body">
									<p> Our state-of-the-art emergency department is staffed 24/7 with 
										skilled physicians, nurses, and support staff, ready to provide immediate medical attention to patients in need.</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
									Inpatient Services <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseTwo" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Our hospital offers comfortable and modern inpatient facilities for individuals 
										requiring hospitalization for various medical conditions. 
										Our multidisciplinary teams collaborate to deliver personalized treatment plans and comprehensive care. </p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
									Surgical Services <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseThree" class="panel-collapse collapse">
								<div class="panel-body">
									<p>From routine surgeries to complex procedures, our team of experienced surgeons utilizes 
										advanced techniques and technologies to ensure optimal outcomes for our patients.</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
									Diagnostic Imaging <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseFour" class="panel-collapse collapse">
								<div class="panel-body">
									<p> Our advanced imaging services, including X-ray, MRI, CT scan, ultrasound, and nuclear medicine, 
										enable accurate diagnosis and treatment planning for a wide range of medical conditions.
									</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
									Laboratory Services <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseFive" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Our fully equipped laboratory facilitates timely and accurate diagnostic testing, supporting our healthcare 
										professionals in delivering precise and effective treatment strategies..</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
									Maternity and Neonatal Care <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseSix" class="panel-collapse collapse">
								<div class="panel-body">
									<p>We provide comprehensive maternity services, including prenatal care, labor and delivery, and postpartum support, 
										ensuring the health and well-being of both mother and baby. 
										Our neonatal intensive care unit (NICU) offers specialized care for newborns requiring extra medical attention.</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseSeven">
									Pediatric Care <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapseSeven" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Our pediatric department is dedicated to providing compassionate and 
										specialized care for children of all ages, from routine check-ups to 
										specialized treatments for pediatric illnesses and conditions.</p>
								</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseEight">
									Rehabilitation Services <span class="fa fa-plus"></span>
									</a>
								</h4>
							</div>
							<div id="collapsEight" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Our comprehensive rehabilitation services, including physical therapy, occupational therapy, 
										and speech therapy, help patients regain strength, 
										mobility, and independence following illness or injury.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="how-works-area">
					<div class="section-heading">
						<h2>How Do We Work</h2>
						<div class="line"></div>
					</div>
					<div class="how-works">
						<ul class="nav nav-tabs" id="myTab">
							<li class="active"><a href="#experiment" data-toggle="tab">Experiential Care</a></li>
							<li><a href="#monitor" data-toggle="tab">Monitor</a></li>
							<li><a href="#clean" data-toggle="tab">Clean</a></li>
							<li><a href="#fast" data-toggle="tab">Fast</a></li>
							<li><a href="#support" data-toggle="tab">Support</a></li>
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane fade in active" id="experiment">
								<p>We understand that navigating healthcare can be overwhelming, which is why 
									our team is dedicated to providing a warm, welcoming environment for all patients 
									and visitors. From our friendly receptionists to our compassionate nurses and physicians, 
									everyone at <strong> Yoya Hospital</strong> is committed to ensuring your comfort and peace of mind throughout your stay.</p>
								<img class="img-center" src="images/c5.jpg" alt="img">
							</div>
							<div class="tab-pane fade " id="monitor">
								<p>Your health and safety are our top priorities. That's why we employ state-of-the-art
									 monitoring technologies and rigorous protocols to continuously track your vital signs and 
									 health status. Our highly skilled medical staff is trained to
									 recognize and respond to any changes in your condition promptly, ensuring optimal care and outcomes.</p>
								<img class="img-center" src="images/c4.jpg" alt="img">
							</div>
							<div class="tab-pane fade " id="clean">
								<p>A clean environment is essential for healing and preventing the spread of infection. 
									At <strong> Yoya Hospital</strong>, we maintain the highest standards of cleanliness and hygiene 
									throughout our facilities. Our dedicated housekeeping team works tirelessly to sanitize 
									patient rooms, common areas, and equipment regularly, 
									using hospital-grade disinfectants to ensure a safe and sanitary environment for all.</p>
								<img class="img-center" src="images/c3.jpg" alt="img">
							</div>
							<div class="tab-pane fade " id="fast">
								<p>Medical emergencies can occur at any time, which is why our hospital 
									is equipped to provide fast and responsive support round-the-clock. 
									Our emergency department is staffed by experienced physicians, 
									nurses, and support staff, ready to provide immediate care and assistance whenever you need it most.</p>
								<img class="img-center" src="images/cu2.jpg" alt="img">
							</div>
							<div class="tab-pane fade " id="support">
								<p>We understand that time is of the essence when it comes to healthcare. 
									That's why we have implemented efficient support services to streamline 
									your experience at <strong> Yoya Hospital.</strong> From quick and hassle-free registration 
									processes to prompt scheduling of 
									appointments and procedures, our goal is to minimize wait times and maximize 
									convenience for our patients.</p>
								<img class="img-center" src="images/cu1.jpg" alt="img">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
