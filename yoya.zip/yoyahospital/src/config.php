<?php
$con = mysqli_connect("localhost:8080", "root", "", "project") or die(mysqli_error($con));
?>
