<section id="service">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="service-area">
					<!-- Start Service Title -->
					<div class="section-heading">
						<h2>Our Services</h2>
						<div class="line"></div>
					</div>
					<!-- Start Service Content -->
					<div class="service-content">
						<div class="row">
							<div class="col-lg-4 col-md-4">
								<div class="single-service">
									<div class="service-icon">
										<span class="fa fa-h-square service-icon-effect"></span>
									</div>
									<h3><a href="#">Comprehensive Medical Healthcare at <strong style="color:blue;">Yoya Hospital</strong></a></h3>
									<p>At Yoya Hospital, we pride ourselves on delivering exceptional medical care with compassion, 
										expertise, and innovation.</p>
								</div>
							</div>
							<div class="col-lg-4 col-md-4">
								<div class="single-service">
									<div class="service-icon">
										<span class="fa fa-medkit service-icon-effect"></span>
									</div>
									<h3><a href="#">Background Checks</a></h3>
									<p>Performing a full background check of our doctors and workers so that our
										patients don’t face any inconvenience.</p>
								</div>
							</div>
							<div class="col-lg-4 col-md-4">
								<div class="single-service">
									<div class="service-icon">
										<span class="fa fa-user-md service-icon-effect"></span>
									</div>
									<h3><a href="#">Specialty Clinics</a></h3>
									<p>We offer a variety of specialty clinics staffed by experts in fields such as cardiology, oncology, 
										neurology, orthopedics, and more, providing specialized care and 
										treatment options for specific medical conditions.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
