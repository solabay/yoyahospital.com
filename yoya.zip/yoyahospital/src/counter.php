<section id="counterSection">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="counter-area">
					<div class="col-lg-3 col-md-3 col-sm-6">
						<div class="counter-box">
							<div class="counter-no counter">
								30
							</div>
							<div class="counter-label">Doctors</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6">
						<div class="counter-box">
							<div class="counter-no counter">
								250
							</div>
							<div class="counter-label">Rooms</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6">
						<div class="counter-box">
							<div class="counter-no counter">
								20
							</div>
							<div class="counter-label">Awards</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6">
						<div class="counter-box">
							<div class="counter-no counter">
								10000
							</div>
							<div class="counter-label">Happy Patients</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
