<section id="whychooseSection">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="service-area">
					<!-- Start Service Title -->
					<div class="section-heading">
						<h2>Why Choose Us</h2>
						<div class="line"></div>
					</div>
				</div>
			</div>
			<div class="col-lg-12 col-md-12">
				<div class="row">
					<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12">
						<div class="whyChoose-left">
							<div class="whychoose-slider">
								<div class="whychoose-singleslide">
									<img src="images/cu1.jpg" alt="img">
								</div>
								<div class="whychoose-singleslide">
									<img src="images/cu2.jpg" alt="img">
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-7 col-md-6 col-sm-6 col-xs-12">
						<div class="whyChoose-right">
							<div class="media">
								<div class="media-left">
									<a href="#" class="media-icon">
										<span class="fa fa-hospital-o"></span>
									</a>
								</div>
								<div class="media-body">
									<h4 class="media-heading">Great Infrastructure</h4>
									<p>At Yoya Hospital, we take pride in offering world-class infrastructure 
										designed to meet the highest standards of modern healthcare. Our state-of-the-art 
										facilities boast the latest advancements in medical technology, including top-of-the-line 
										laboratories and testing equipment. With our commitment to excellence, we ensure that our 
										patients receive nothing but the best results and accurate diagnoses, thanks to our unparalleled infrastructure.</p>
								</div>
							</div>
							<div class="media">
								<div class="media-left">
									<a href="#" class="media-icon">
										<span class="fa fa-user-md"></span>
									</a>
								</div>
								<div class="media-body">
									<h4 class="media-heading">Qualified and Dedicated Physicians</h4>
									<p>Our team of doctors is comprised of highly qualified professionals 
										who are passionate about providing exceptional care to our patients. 
										With years of experience and expertise in their respective fields, 
										our doctors are dedicated to addressing all your healthcare needs with 
										precision and compassion. Whether you require routine check-ups, specialized treatments, or complex surgical procedures,
									 our qualified physicians are here to provide personalized care tailored to your individual needs.</p>
								</div>
							</div>
							<div class="media">
								<div class="media-left">
									<a href="#" class="media-icon">
										<span class="fa fa-ambulance"></span>
									</a>
								</div>
								<div class="media-body">
									<h4 class="media-heading">Rapid Emergency Support</h4>
									<p>In times of medical emergencies, every second counts. 
										That's why we prioritize providing swift and efficient emergency support 
										to our patients. Our streamlined processes ensure fast test reports and 
										prompt medical attention, allowing us to cater to our patients' needs with 
										urgency and efficiency. At Yoya Hospital, you can rest assured that you will 
										receive the timely care and support you need during 
										critical moments, helping to ensure optimal outcomes and peace of mind for you and your loved ones.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
